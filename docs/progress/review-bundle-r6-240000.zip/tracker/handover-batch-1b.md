# تسليم Batch 1B (للوكيل الجديد)

تاريخ التسليم: 2026-10-29 · الفرع: `fix/phase1-financial-report-authz` · المستودع: `D:\Web\AqarBooks`

## 0. القواعد الثابتة (لا تُكسر)
- **r6 فقط.** لا تطوير، لا إنتاج، لا اتصال بقاعدة غير r6. لا تقرأ أسرار من مجلد `C:\Users\Lenovo\AppData\Local\Temp\g0-r6` ولا تطبعها.
- **لا** commit، ولا push، ولا نشر، ولا Batch 2، ولا بيان "جاهزية الإنتاج".
- **لا تطبّق** أي ترحيل خارج r6. كل الترحيلات المقترحة ملفات مراجعة في `docs/progress/proposals/` وقد طُبّقت على r6 فقط.
- **الاعتماد يحتاج نصًا صريحًا من المستخدم.** التوصية ليست اعتمادًا.
- **التأجيل ≠ النجاح.** الاختبار المؤجل يُعلَّم `test.fixme` ويظهر مُتخطّى.
- لا تُخفّف تأكيدًا ولا ترفع مهلة ولا تحذف دليلًا ولا قاعدة بيانات.
- لا تعِد اختبارات غير متأثرة. أعد المتأثر فقط.
- Migrations immutable: لا تعدّل ملفات `supabase/migrations/` القديمة، والترحيل الجديد ملف forward-only.

## 1. الحالة الحالية باختصار
- **Batch 1B مفتوحة (`in_progress`)** في `docs/progress/status.json`؛ القرارات الخارجية لا توقف العمل المستقل، ولا تُغلق الدفعة قبل استكمال البنود في `ROADMAP.md`.
- الترحيلات 120000–230000 مطبّقة على r6، ورُوجعت محليًا. فصل 220000 صافي الحارس عن الصافي المحايد للحالة، وأضاف 230000 حارسًا مؤجلًا لإلغاء المسودة بالحالة. **قُبلت نتيجة المراجعة بتأكيد المالك النصي «قبول» في 2026-10-31 وأُغلق REL-02**؛ لم يُطبّق شيء خارج r6.
- **التسليم للمراجعة: حزمة `docs/progress/review-bundle-r6-240000.zip` الجاهزة للتوقيع البشري.** تضم الترحيلات 120000–240000 والأدلة والفروق ونتائج الحارس والعكس؛ بصمتها محفوظة بجانبها في ملف `.sha256`. نقطة التوقيع `review-signoff-batch-1b.md` ما زالت معلقة، وتبقى Batch 1B بحالة `in_progress` حتى قبول صريح.

## 2. ما الذي طُبّق على r6 (بالترتيب)
| الملف | الوظيفة | الحالة |
|---|---|---|
| `proposals/20261029120000_project_posting_lock_guard.sql` | حارس حقول المشروع، قفل `FOR UPDATE`، تدقيق `PROJECT_UPDATED`، وسحب DELETE/TRUNCATE من anon/authenticated | مطبّق على r6، تراجع مُختبر؛ ضمن REL-02 المقبول |
| `proposals/20261029130000_project_line_lock_and_wip_floor.sql` | قفل سطر المشروع وأرضية WIP لكل صف | مطبّق ثم مُستبدل |
| `proposals/20261029140000_project_wip_summary_reversals.sql` | تصنيف العكس حسب القيد الأصلي | مطبّق ثم استُكمل بـ200000 |
| `proposals/20261029150000_manual_journal_no_project_tag.sql` | منع وسم القيد اليدوي بمشروع | مطبّق على r6، اختبارات A1–A7 ناجحة |
| `proposals/20261029160000_project_wip_floor_at_commit.sql` | فحص صافي الأرضية عند الالتزام | مطبّق ثم مُستبدل |
| `proposals/20261029170000_wip_floor_on_line_update.sql` | تغطية التحديث والنقل بين المشاريع | مطبّق ثم مُستبدل |
| `proposals/20261029180000_wip_floor_baseline_and_delete.sql` | تغطية الحذف وخط أساس الرصيد السالب | مطبّق على r6؛ السياسة محسومة ضمن REL-03: التحسين فقط |
| `proposals/20261029190000_project_wip_negative_message.sql` | توضيح أن الرقم الثاني صافٍ متوقع بعد الحركة المرفوضة | مطبّق على r6، تغيير لفظي فقط |
| `proposals/20261029200000_project_wip_summary_cancelled_drafts.sql` | استبعاد المسودة الملغاة بالحالة فقط من تصنيف WIP، مع إبقاء العكس الحقيقي | مطبّق على r6؛ الواجهة 8/8 |
| `proposals/20261029210000_project_wip_net_status_neutral.sql` | إبقاء صافي جميع الأسطر محايدًا لتغيير حالة القيد | مطبّق على r6؛ اختبار قبل/بعد ناجح |
| `proposals/20261029220000_project_wip_floor_ignore_cancelled_drafts.sql` | صافي مستقل للحارس يستبعد المسودات الملغاة من خط الأساس والفحص | مطبّق على r6؛ السالب والتحسين والسباق والإطلاق ناجحة |
| `proposals/20261029230000_project_status_cancellation_floor.sql` | قفل وخط أساس قبل إلغاء المسودة بالحالة وفحص مؤجل بعده، مع استثناء العكس الحقيقي | مطبّق على r6؛ الإلغاء المخالف مرفوض والمسارات المتأثرة ناجحة؛ رُوجع ساكنًا مع فرقه وخطة تراجعه دون Critical أو Required في `docs/progress/review-230000-sql.md` |
| `proposals/20261029240000_disposal_proceeds_cash_only.sql` | قصر حصيلة الاستبعاد الموجبة على حساب نقدية/بنك صالح، ورفض حساب الأصل ومجمع الإهلاك وطالب مركز التكلفة | **مطبّق على r6 فقط ضمن REL-03؛ رُوجع محليًا في `review-240000-sql.md`، وأُغلقت ملاحظة تمييز الحساب غير النقدي دون تغيير SQL** |

**تراجع:** ملف `concurrency/rollback_to_pre_migration.sql` للترحيل 120000. للترحيلات الأخرى: التراجع موثّق في رأس كل ملف. قيد `check_audit_action` الموسّع **يبقى** بعد التراجع لأن صفوف `PROJECT_UPDATED` مُجزّأة ولا تُحذف؛ هذا الأثر مشمول بقبول REL-02 المسجل.

## 3. الكود المعدَّل في التطبيق (على شجرة العمل، غير ملتزم)
- `lib/actions/projects.ts`: `saveProject` (upsert) استُبدل بـ`createProject` (insert يرفض الكود المكرر بـ`PROJECT_CODE_EXISTS`) و`updateProject` (تعديل صريح، صلاحية `finance.accounts.manage`، قفل الحقول بعد الحركات بـ`PROJECT_HAS_POSTINGS`).
- `app/[locale]/(app)/finance/projects/project-forms.tsx`: وضع إنشاء/تعديل، حسابات WIP والتكلفة اختيارية عند الإنشاء، رسائل عربية/إنجليزية للأخطاء الجديدة.
- `projects-client.tsx` و`projects/page.tsx`: زر تعديل لمن يملك الصلاحية، وإرفاق الحقول المخزّنة (`property_id`, `wip_account_id`, `cost_of_sales_account_id`).
- `assets/asset-forms.tsx` و`assets-client.tsx` و`page.tsx`: `organizationId` مخفي في نموذج التسجيل والإهلاك، وحقل `proceedsAccountId` (حساب حصيلة الاستبعاد) في نموذج الاستبعاد.
- `app/[locale]/(app)/finance/reports/lease-expirations/page.tsx`: الاستعلام يتبع العلاقة الصحيحة `units.property_id → properties` والهاتف من `member_phones`. (الفرق: `docs/progress/evidence-r6-run3/lease-page.diff`.)
- `reports-hub-client.tsx` و`layout.tsx`: حُذفت روابط تقرير الأصول وCAM وCAPEX/OPEX.
- `lib/auth`: لم يُعدَّل.

## 4. القرارات والاعتمادات (مع المرجع)
- **تأجيل تقارير الأصول وCAM وCAPEX/OPEX:** معتمد بنص صريح؛ الروابط مخفية، والاختبارات `test.fixme` باسم DEFERRED. انظر `docs/progress/decisions/2026-10-29-report-deferrals.md`.
- **الخيار A (منع وسم القيد اليدوي بمشروع):** معتمد بنص صريح. انظر `docs/progress/decisions/2026-10-29-manual-journal-project-tag.md`.
- **تصنيف العكس والمسودة الملغاة:** مكتمل. المسودة التي لم تُرحّل لا تظهر كإطلاق، والقيد المرحّل المعكوس يحتفظ بتصنيفه وأثر عكسه.
- **UPDATE/DELETE لأدوار `authenticated` و`anon`:** قرر المالك في 2026-10-30 إبقاءها كما هي دون فتح الكتابة؛ ليست عائقًا لإغلاق Batch 1B، وأي توسعة مستقبلية تحتاج اعتمادًا جديدًا واختبارات موجهة.
- **REL-02:** مقبول ومغلق بتأكيد المالك النصي «قبول» في 2026-10-31؛ مسجل في `docs/progress/review-signoff-120000-230000.md` دون اعتماد إنتاج.
- **REL-03:** مغلق على r6 في 2026-10-31: «التحسين فقط» للرصيد السالب، والنقدية/البنوك فقط لحصيلة البيع الموجبة، ولا ذمم آجلة أو مقايضة. طُبّق 240000 على r6 فقط؛ التكامل 8/8، وPlaywright ‏1/1، وTypeScript والبناء ناجحان. التفاصيل والأدلة في `docs/progress/disposal-proceeds-account-recommendation.md` و`docs/progress/evidence-r6-run10/`؛ لا اعتماد إنتاج.

## 5. حالة الاختبارات (r6)
| الملف | النتيجة | ملاحظات |
|---|---|---|
| `projects-wip.spec.ts` | **8/8 ناجح** في `evidence-r6-run5/results/projects-wip-ui-after.txt` | نتيجة سابقة؛ لم تُعد الواجهة في 220000 أو 230000 |
| `cancelled_debit_status_guard.sql` بعد 230000 | أُعيد على r6 في `results/cancelled_debit_status_guard_recheck.txt`: قبل الإلغاء `floor_net=100`، وبعده `-200`، ورفضته القيود المؤجلة قبل ROLLBACK؛ بعده الصافي والحارس والدفتر 100 والحالة DRAFT | ملاحظة الحارس مغلقة؛ لا SQL جديد |
| `cancelled_credit_release_regression.sql` بعد 220000 و230000 | إطلاق 600 مقبول، والقيد POSTED متوازن، وWIP والقيود 400، و`SET CONSTRAINTS` ناجح | لم يتأثر الإلغاء الدائن الصحيح |
| `negative_and_improvement.sql` بعد 220000 | رُفض 1000 إلى -500 دون كتابة؛ قُبل تحسين -500 إلى -400 | بيانات معزولة ونظيفة |
| ترتيبا سباق الإطلاق والعكس بعد 220000 و230000 | الأول 1000/600/400 والثاني 0/0/0؛ القيود غير المتوازنة صفر | أُعيدا بعد كل تغيير متأثر |
| `posted_reversal_regression.sql` بعد 230000 | عكس الإطلاق 1000/0/1000 ثم عكس الرسملة 0/0/0 | العكس الحقيقي مستثنى من حارس إلغاء المسودة |
| `cancelled_draft_regression.sql` بعد 210000 | ناجح: 1000 مرسمل، 600 مُطلق، 400 WIP والقيود 400 | لم يتغير تصنيف المسودة |
| `two_project_multiline_update_ordering.sql` | **الترتيبان ناجحان**؛ الصافي النهائي 400/400 رغم سالب مؤقت في كل اتجاه | أُغلق البند المحلي المتبقي |
| `cancelled_debit_release_regression.sql` | رُفض إطلاق 1500 على رصيد مرحّل 1000 دون كتابة؛ نجح إطلاق 600 وانتهى WIP إلى 400 | نتيجة سابقة ناجحة |
| `reports-suite-flow.spec.ts` | ناجح (1) + مُتخطّى (1: الأصول، مؤجل) | التخطي ليس نجاحًا |
| `reports-unbuilt-sections.spec.ts` | مُتخطّى (2: CAM, CAPEX، مؤجلة) | اسم الملف قديم، محتواه مؤجل |
| `reports-lease-expirations.spec.ts` | 1/1 ناجح | عزل المؤسسات |
| `reports-lease-read-failure.spec.ts` | 1/1 ناجح | يحقن فشل قراءة ويستعيد المنحة |
| `accounting-journey.spec.ts` | 15/15 ناجح | نتيجة محفوظة |
| `fixed-asset-disposal.integration.test.ts` بعد 240000 ومراجعته | **8/8 ناجح** في 16.152 ثانية؛ حساب `ASSET` غير نقدي مستقل (`1230`) رُفض بلا قيد وبقي الأصل ACTIVE | الدليل `evidence-r6-run10/results/rel03-review-integration.txt`؛ التصحيح أغلق ازدواج شرط النقدية مع شرط حساب الأصل |
| `asset-disposal.spec.ts` بعد 240000 ومراجعته | **1/1 ناجح** في 62.277 ثانية؛ الحساب غير النقدي المستقل غير ظاهر، ثم استبعاد متوازن | الدليل `rel03-review-e2e-optimized.txt`؛ محاولة المراجعة الأولى انتهت بمهلة أثناء الإغلاق بعد التحققات وأثرها محفوظ؛ لم تُشغّل المجموعة كاملة |
| `fixed-assets.spec.ts` | نتيجة سابقة ناجحة | لم يتأثر بتغيير حساب الحصيلة ولم يُعد |
| `owner-portal-online-payment-fawry.spec.ts` | **غير مُشغَّل** (مفاتيح Fawry غائبة) | عائق خارجي لا يوقف العمل المستقل |
| Vitest (20 ملفًا) | 4 أُعيد تشغيلها ناجحة، و15 بنتيجة الجولة الأولى، و`sandbox-pilot.manual` 3/9 | 6 تأكيدات ضريبية غير متحققة لغياب قواعد معتمدة |

قاعدة الحارس: `concurrency/` يحتوي نتائج T1–T5 وR1/R2 وQ والحذف والنقل والرصيد السالب. إعادة المحاولة تحت تنازع متزامن أُثبتت في `evidence-r6-run4/results/retry_valid_missing_attempt.txt`: انتظرت 3.907 ثوانٍ ثم التزمت، والقيدان POSTED والقيود غير المتوازنة صفر.

**التحقق من TypeScript:** نجح الفحص المباشر بعد تصحيح اختباري مراجعة 240000 بـ`exit 0` (`evidence-r6-run10/results/tsc-rel03-review-status.txt`). لم يتغير كود التطبيق أو SQL في هذه المراجعة، لذلك لم يُعد البناء.

## 6. ما لم يُختبر أو مفتوح
- **تحديث كشف الدفتر متعدد الأسطر:** اكتمل بالترتيبين، ولا يبقى بند اختبار محلي يمنع التسليم للمراجعة.
- **الحذف والتحديث:** مُغطّيان للأدوار المتجاوزة لـRLS فقط (المالك وservice_role). `authenticated` و`anon` لا يملكان سياسة UPDATE/DELETE على `journal_entry_lines`؛ توسيعهما يحتاج قرار أمن/منتج.
- **السلوك القائم:** `release_project_wip` بلا فحص حالة المشروع موثق للمراجعة، وليس عيبًا جديدًا من ترحيلات WIP الحالية.
- **Fawry والضرائب:** عائقان خارجيان لا يوقفان العمل المستقل.
- **بيئة r6 نفسها:** بيانات اختبار متراكمة ولم تُنظَّف عمدًا. لا حذف للبيانات القديمة.

## 7. تشغيل r6 (مرجع سريع)
- **الحاويات:** `g0r6-db` (Postgres)، `g0r6-kong` (API)، `g0r6-auth`، `g0r6-rest`، `g0r6-storage`. الـAPI على `127.0.0.1:58461`.
- **تطبيق Next:** يُبنى ويُشغّل بسكربت `C:/Users/Lenovo/AppData/Local/Temp/g0-r6-run/app-r6.mjs` (أوضاع: `build`، `start`، `pwo <spec> <outdir>`، `pw`). يحقن متغيرات r6 فقط ويفرّغ `.env.local`.
- **بعد أي تغيير في واجهة التطبيق يجب إعادة البناء** (`build` ثم `start`). الخادم القديم يخدم بناءً قديمًا.
- **Playwright:** المتغير `LOCAL_SUPABASE_API_PORTS=58461` ضروري، وإلا يرفض الحارس التشغيل.
- **Kong:** تعديل `proxy_buffer_size` داخل الحاوية فقط، ويضيع عند إعادة إنشاء الحاوية. التفاصيل في `docs/progress/b1b-r6-run3-gateway-and-pilot.md`.
- **الإيقاف:** أوقف عملية التطبيق على المنفذ 3100 بـ`taskkill //PID <pid> //F` (الشرطتان المزدوجتان مهمّتان في Git Bash).

## 8. مآخذ تشغيلية تعلّمناها (لا تكررها)
- في Git Bash: `docker exec ... sh -c "..."` مع اقتباسات متداخلة يفشل بصمت. استعمل ملف SQL مؤقتًا (`docker cp` ثم `psql -f`).
- معرّفات UUID تُكتب سداسية عشرية فقط. حرف مثل `g` يفشل التنفيذ كله.
- لا تشغّل `find /` (بطيء جدًا). ابحث داخل المستودع فقط.
- Playwright يمسح `test-results` في كل تشغيل. استعمل `--output` لحفظ الأدلة خارجه.
- ملفات `.tsx` داخل `docs/` تُجمَّع من `tsc` إن كانت صالحة. انقل النسخ الأساسية إلى `.txt`.
- تعديل ملف يتطلب قراءته أولًا بأداة `Read`.
- `sed -i` على ملفات CRLF يحافظ على الأسطر، لكن `node -e` مع backticks داخل الاقتباس يفشل. اكتب النص في ملف مؤقت.
- الحقول المعروضة في الواجهة قد تكون غير مطابقة للاختبار القديم؛ تحقّق من الكود قبل تعديل توقع الاختبار، واكتب سبب التعديل.
- يجب أن يكون الاختبار المُصلَح يثبت المعنى نفسه، لا أن يجعل الاختبار ينجح بأي شكل.

## 9. ماذا يفعل الوكيل الجديد أولًا
1. اقرأ جدول Batch 1B في `docs/progress/ROADMAP.md` ثم `docs/progress/status.json`؛ هما المتتبع الحالي.
2. راجع `review-bundle-r6-240000` ومانيفسته؛ يضم الترحيلات والأدلة النهائية حتى 240000، مع بقاء حزمة 230000 سجلًا تاريخيًا لقبول REL-02.
3. لا تبدأ جولة جديدة إلا لعيب مثبت أو لبند محلي محدد في الجدول، ولا تتصل بالتطوير أو الإنتاج.
4. عند أي تحديث لاحق، حدّث المتتبع القائم وأرفق الفرق والنتائج؛ لا تنشئ نظام تتبع جديدًا.

## 10. مراجع أساسية
- المتتبع: `docs/progress/ROADMAP.md` و`docs/progress/status.json`.
- نقطة التوقيع الحالية: `docs/progress/review-signoff-batch-1b.md`؛ معلقة للمراجعة البشرية ولا تُغلق Batch 1B تلقائيًا. قبول REL-02 السابق محفوظ في `review-signoff-120000-230000.md` دون إعادة فتحه أو اعتماد إنتاج.
- الخطط والتحقيقات: `docs/progress/b1b-r6-run3-gateway-and-pilot.md`، و`docs/progress/proposals/project-posting-lock-guard-review.md`، و`docs/progress/proposals/manual-journal-project-tagging-design.md`.
- القرارات: `docs/progress/decisions/`.
- الأدلة: `docs/progress/evidence-r6-run3/`، و`evidence-r6-run4/`، و`evidence-r6-run5/`، و`evidence-r6-run6/`، و`evidence-r6-run7/`، و`evidence-r6-run8/`، و`evidence-r6-run9/`، و`evidence-r6-run10/`.
- حزمة التسليم الحالية: `docs/progress/review-bundle-r6-240000.zip`؛ حزمة `review-bundle-r6-230000.zip` محفوظة كسجل REL-02 المقبول.
