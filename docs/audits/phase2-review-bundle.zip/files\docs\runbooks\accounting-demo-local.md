# Running the accounting demo and its browser tests locally

Everything here runs on your machine only. The stack is a **separate, clean** Supabase project
(`aqarbooks_clean`, API `127.0.0.1:55321`, DB `127.0.0.1:55322`) that is independent of the development stack
(`aqarbooks`, `:54321`) and never touches the hosted project in `.env.local`.

## What protects against external connections
| Layer | How |
|---|---|
| Supabase | the clean stack has no SMTP, no analytics, no realtime, no edge runtime, sign-up disabled (`scripts/demo-local/supabase/config.toml`) |
| App process | `scripts/demo-local/app.mjs` overrides **every** variable named in `.env.local` / `.env.production` / `.env` with a blank, then sets the local stack's URL/keys. Production URLs, keys and provider credentials never reach Next.js. AI provider keys are blank, so no AI route can call a provider; the AI entry points are hidden (`lib/ai/availability.ts`) |
| Playwright config | `playwright.config.ts` refuses to start unless the Supabase URL is a known local API (`tests/helpers/local-target.ts`, port 55321 only via `LOCAL_SUPABASE_API_PORTS`) and the app host is loopback |
| Browser | `tests/e2e/helpers/local-only.ts` aborts any request whose host is not `localhost` / `127.0.0.1` and fails the test if one was attempted |
| Vitest | `tests/setup/local-only-guard.ts` (Supabase client constructor guard) |

## Steps
Requires Docker Desktop running, the Supabase CLI, Node, and the Playwright browsers (`npx playwright install chromium`).

```bash
# 1. clean stack: applies supabase/migrations through `supabase start`
npm run demo:stack-up
npm run demo:stack-verify        # ledger == files, and `db diff` finds no drift
# (after you add a migration:  npm run demo:stack-migrate)

# 2. the app on http://localhost:3100, isolated environment
#    production build (small, fast, writes almost nothing - preferred; the dev server's cache can fill a small disk):
node scripts/demo-local/build.mjs --next-only
node scripts/demo-local/start-prod.mjs     # leave running
#    or the dev server:
# npm run demo:app

# 3. the connected journey, as an accountant, through the UI (new organization each run, ~8 min the first time)
npm run demo:e2e -- tests/e2e/accounting-journey.spec.ts
npm run demo:e2e -- tests/e2e/accounting-bank-reconciliation.spec.ts
npm run demo:e2e -- tests/e2e/accounting-receivable-default.spec.ts tests/e2e/accounting-void-permission.spec.ts tests/e2e/re-prior-year-boundary.spec.ts

# re-run single verification steps against the organization the last run built
JOURNEY_REUSE=1 npm run demo:e2e -- tests/e2e/accounting-journey.spec.ts -g "V5"

# stop and delete the clean stack (data is disposable)
npm run demo:stack-down
```

After a journey run, browse the same data yourself: sign in at `http://localhost:3100/en/login` as
`accountant-<tag>@demo.local` (or `auditor-<tag>@demo.local`); `<tag>` and the organization name are written to
`test-results/demo-org.json`. The local-only fixture password is the constant `PASSWORD` in
`tests/e2e/helpers/accounting-fixture.ts`.

## What the journey proves (see `docs/audits/Phase2-Accounting-Journey-Acceptance-Report-2026-10-10.md`)
Opening balance 10,000 (dated 2025-12-31) → new due 2,000 → receipts 1,500 and 500 → full reversal of the second →
net collected 1,500, outstanding 10,500, shown identically in the dues list, receipts, owner statement, general
ledger, trial balance (opening + movement = closing), income statement, balance sheet, cash flow, aging and the
audit trail.

## Notes
* The first visit to each page compiles it (dev server), so the first run is slow.
* Roles: the journey's accountant is the shipped ACCOUNTANT template **plus** `finance.payments.void`, created by the
  fixture, so the same session can reverse a receipt. The shipped ACCOUNTANT template cannot void.
* `BANK_TRANSFER` is selectable in the receipt dialog (round 2c); the receipts list, filter and bank-collections KPI classify it.
* The organization's **approved receivable account** (`organization_finance_settings.receivable_account_id`) is set by the owner
  (`set_default_receivable_account`, or the checkbox in the issue-due dialog). Without it the dialog is empty and asks for a choice.
* Reversing a receipt needs `finance.payments.void` (owner and finance-manager templates). The demo accountant has it added.
* Playwright artifacts go to the system temp folder (`PW_OUTPUT_DIR` to change it).
* The existing Playwright specs read `.env.local` through dotenv. With the new config guard they only start when you
  run them through `npm run demo:e2e` (clean stack) or point the variables at the dev stack (`54321`) yourself.
* **Bank reconciliation:** finalize needs a zero difference **and** every statement line matched to a booked entry; there is no
  "explain / defer" exception. Importing a bank fee does not book it: create the entry (accountant), submit it, have the
  owner post it, then match.
* **Dues and opening balances need an OPEN fiscal period** covering their date; otherwise they are refused with
  `FISCAL_PERIOD_MISSING` / `FISCAL_PERIOD_NOT_OPEN` and nothing is created. Opening balances cannot be future-dated.
* **Issue due:** an identical due that already exists is reported as "Due already exists", not "issued".
* **Issue due:** if only the optional "approve as default" step fails, the due is still issued; use the toast's *Retry saving*.
* Review bundle: `node scripts/demo-local/make-review-bundle.mjs` then `node scripts/demo-local/verify-review-bundle.mjs`.
* **Upgrading a database that applied the earlier Phase 2c text:** apply `20261014100000_phase2e_bank_reconciliation_strict_upgrade.sql`
  (the normal `supabase migration up` does). It audit-retires any still-explained statement lines, removes the explanation
  mechanism and restores the strict finalize. Rehearsal: `node scripts/demo-local/run-vitest-local.mjs --no-file-parallelism tests/bank-reconciliation-upgrade.integration.test.ts`
  (puts the local clean database into the old state, upgrades it in place, and checks data, audit and behaviour).
