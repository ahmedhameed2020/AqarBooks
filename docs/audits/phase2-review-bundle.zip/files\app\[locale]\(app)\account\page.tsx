import { setRequestLocale } from "next-intl/server";
import { redirect } from "@/i18n/navigation";
import { getCurrentUser, isPlatformAdmin } from "@/lib/auth/session";
import { getPrimaryOrganization } from "@/lib/auth/org-context";
import { createClient } from "@/lib/supabase/server";
import type { Locale } from "@/i18n/routing";
import { AccountClient, type AccountUserMetadata } from "./account-client";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  const isAr = locale === "ar";
  return {
    title: isAr
      ? "إدارة الحساب الشخصي والأمان — AqarBooks"
      : "User Account & Security Settings — AqarBooks",
    description: isAr
      ? "إدارة الملف الشخصي، كلمة المرور، أمان الجلسات، وتفضيلات الإشعارات والتنبيهات."
      : "Manage your personal profile, security credentials, active sessions, and notification preferences.",
  };
}

export default async function AccountPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale as Locale);
  const isAr = locale === "ar";

  const user = await getCurrentUser();
  if (!user) {
    redirect({ href: "/login", locale: locale as Locale });
  }

  const [platformAdmin, organization] = await Promise.all([
    isPlatformAdmin(user!.id),
    getPrimaryOrganization(user!.id),
  ]);

  const supabase = await createClient();

  // Fetch user profile from database
  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name, avatar_url, locale")
    .eq("id", user!.id)
    .maybeSingle();

  // Fetch user role in the organization if available
  let userRole = isAr ? "عضو معتمد" : "Member";
  if (organization) {
    const { data: membership } = await supabase
      .from("organization_memberships")
      .select("status")
      .eq("organization_id", organization.id)
      .eq("user_id", user!.id)
      .maybeSingle();

    if (membership?.status === "active") {
      // Show the role(s) actually assigned, not a fixed "Organization Owner".
      const { data: assignments } = await supabase
        .from("user_role_assignments")
        .select("roles(name_ar, name_en)")
        .eq("organization_id", organization.id)
        .eq("user_id", user!.id);
      const names = (assignments ?? [])
        .map((a) => {
          const r = a.roles as unknown as { name_ar?: string | null; name_en?: string | null } | null;
          return isAr ? r?.name_ar ?? r?.name_en : r?.name_en ?? r?.name_ar;
        })
        .filter((n): n is string => Boolean(n));
      if (names.length) userRole = names.join(isAr ? "، " : ", ");
    }
  }

  return (
    <AccountClient
      user={{
        id: user!.id,
        email: user!.email ?? "",
        created_at: user!.created_at,
        last_sign_in_at: user!.last_sign_in_at,
        user_metadata: (user!.user_metadata as AccountUserMetadata) ?? {},
      }}
      profile={profile}
      organizationName={organization?.name || (isAr ? "المنشأة الرئيسية" : "Main Organization")}
      userRole={userRole}
      isPlatformAdmin={platformAdmin}
      locale={locale}
    />
  );
}
