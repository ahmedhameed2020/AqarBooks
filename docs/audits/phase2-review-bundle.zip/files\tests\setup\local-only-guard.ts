/**
 * Global vitest setup: every Supabase client a test (or the app code it imports) constructs
 * must point at a known local stack. The check runs inside createClient(), i.e. before the
 * first request, so a mis-pointed .env.local fails the suite before any write happens.
 */
import { vi } from "vitest";
import { assertKnownLocalSupabaseUrl } from "../helpers/local-target";

vi.mock("@supabase/supabase-js", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@supabase/supabase-js")>();
  return {
    ...actual,
    createClient: ((url: string, ...rest: unknown[]) => {
      assertKnownLocalSupabaseUrl(url);
      return (actual.createClient as (...a: unknown[]) => unknown)(url, ...rest);
    }) as typeof actual.createClient,
  };
});
