/**
 * Single source of truth for "is this Supabase URL a known local test environment?".
 *
 * Test suites that write data must never reach a hosted project. Local means: an http URL
 * whose host is loopback AND whose port is the Supabase CLI's default API port (54321),
 * or port 1, the reserved unroutable port used as a harmless dummy in unit runs.
 * The error names only host:port -- never keys, passwords, or the full URL.
 */
const LOOPBACK_HOSTS = new Set(["127.0.0.1", "localhost", "[::1]", "::1"]);
const DEFAULT_LOCAL_PORTS = ["54321", "1"];

/**
 * Extra loopback API ports may be opted in explicitly (the separate clean demo stack uses 55321):
 * LOCAL_SUPABASE_API_PORTS=55321. Only digits are accepted, and the host check below still applies,
 * so an opt-in can never point a test at a non-loopback address.
 */
function knownLocalPorts(): Set<string> {
  const extra = (process.env.LOCAL_SUPABASE_API_PORTS ?? "")
    .split(",")
    .map((p) => p.trim())
    .filter((p) => /^\d{2,5}$/.test(p));
  return new Set([...DEFAULT_LOCAL_PORTS, ...extra]);
}

export function describeTarget(url: string): string {
  try {
    const u = new URL(url);
    return `${u.hostname}${u.port ? `:${u.port}` : ""}`;
  } catch {
    return "<unparseable url>";
  }
}

export function isKnownLocalSupabaseUrl(url: unknown): boolean {
  if (typeof url !== "string" || url.length === 0) return false;
  let u: URL;
  try {
    u = new URL(url);
  } catch {
    return false;
  }
  if (u.protocol !== "http:") return false;
  if (u.username || u.password) return false;
  return LOOPBACK_HOSTS.has(u.hostname) && knownLocalPorts().has(u.port);
}

export function assertKnownLocalSupabaseUrl(url: unknown): void {
  if (isKnownLocalSupabaseUrl(url)) return;
  const shown = typeof url === "string" ? describeTarget(url) : String(url);
  throw new Error(
    `Refusing to run: test target ${shown} is not a known local Supabase API (expected http://127.0.0.1:54321 or localhost). ` +
      "Tests that write data run only against the local stack. Start it with `supabase start` and set " +
      "NEXT_PUBLIC_SUPABASE_URL / NEXT_PUBLIC_SUPABASE_ANON_KEY / SUPABASE_SERVICE_ROLE_KEY from `supabase status -o env`.",
  );
}
