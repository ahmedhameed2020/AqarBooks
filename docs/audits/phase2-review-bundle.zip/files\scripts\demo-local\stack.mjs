#!/usr/bin/env node
// node scripts/demo-local/stack.mjs up|down|status|verify
// A throwaway, separate Supabase stack (project id aqarbooks_clean, API 55321, DB 55322): auth + rest +
// storage only, no SMTP, no analytics, no realtime. Applies supabase/migrations through `supabase start`.
import { supabase, stackEnv, syncStackProject, root } from "./lib.mjs";
import { execFileSync } from "node:child_process";
import { readdirSync } from "node:fs";
import { join } from "node:path";

const cmd = process.argv[2] ?? "status";
if (cmd === "up") {
  syncStackProject();
  console.log(supabase(["start"]).split("\n").filter((l) => /Applying|Started|error/i.test(l)).join("\n"));
} else if (cmd === "migrate") {
  // apply migrations added since `up` (copies the repo migrations, then the usual `supabase migration up`)
  syncStackProject();
  console.log(supabase(["migration", "up", "--local"]));
} else if (cmd === "down") {
  console.log(supabase(["stop", "--no-backup"]));
} else if (cmd === "status") {
  const e = stackEnv();
  console.log(`API ${e.API_URL}  DB ${e.DB_URL}`);
} else if (cmd === "verify") {
  const e = stackEnv();
  const psql = (sql) => execFileSync("docker", ["exec", "supabase_db_aqarbooks_clean", "psql", "-U", "postgres", "-d", "postgres", "-tA", "-c", sql], { encoding: "utf8" }).trim();
  const ledger = psql("select version from supabase_migrations.schema_migrations order by 1").split("\n").filter(Boolean);
  const files = readdirSync(join(root, "supabase", "migrations")).filter((n) => /^\d{14}_/.test(n)).map((n) => n.slice(0, 14)).sort();
  const same = ledger.length === files.length && ledger.every((v, i) => v === files[i]);
  console.log(`ledger ${ledger.length} / files ${files.length} → ${same ? "MATCH" : "MISMATCH"}`);
  const raw = supabase(["db", "diff", "--local", "--schema", "public", "-o", "json"]);
  const json = JSON.parse(raw.slice(raw.indexOf("{"), raw.lastIndexOf("}") + 1));
  const clean = !json.diff?.trim() && (json.dropStatements ?? []).length === 0;
  console.log(clean ? "db diff (public): no schema changes" : "db diff: DRIFT " + json.diff);
  if (!same || !clean) process.exit(1);
  void e;
}
