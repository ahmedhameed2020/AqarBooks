import { type ReactNode } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

/**
 * Phase 1.2 — the tenant dashboard must not query, nor render figures for, finance data the
 * viewer cannot read, and a failed query must read as an error, never as zero.
 *
 * The real server component is rendered with a recording Supabase stand-in and a permission
 * set per case; child widgets are stubbed to plain text so the assertions are about which
 * sections exist and which queries ran.
 */
vi.mock("server-only", () => ({}));
vi.mock("@/i18n/navigation", () => ({
  Link: ({ children, locale: _l, ...p }: { children?: ReactNode; locale?: string } & Record<string, unknown>) => <a {...p}>{children}</a>,
}));
vi.mock("@/app/[locale]/(app)/dashboard/kpi-card", () => ({
  KpiCard: ({ label, value, hint }: { label: string; value: ReactNode; hint?: string }) => <div data-kpi={label}>{value}{hint ? `|${hint}` : ""}</div>,
  MiniStat: ({ label, value }: { label: string; value: string }) => <div data-mini={label}>{value}</div>,
}));
vi.mock("@/app/[locale]/(app)/dashboard/count-up", () => ({ CountUp: ({ value }: { value: number }) => <span>{value}</span> }));
vi.mock("@/app/[locale]/(app)/dashboard/charts", () => ({
  RevenueExpenseTrend: () => <div data-widget="trend" />,
  AgingChart: () => <div data-widget="aging" />,
  CollectionTargetGauge: () => <div data-widget="gauge" />,
}));
vi.mock("@/app/[locale]/(app)/dashboard/insights-card", () => ({ InsightsCard: () => <div data-widget="insights" /> }));
vi.mock("@/components/ai/executive-financial-insights-card", () => ({ ExecutiveFinancialInsightsCard: () => <div data-widget="ai-insights" /> }));
vi.mock("@/app/[locale]/(app)/dashboard/dashboard-actions", () => ({ DashboardActions: () => <div data-widget="actions" /> }));
vi.mock("@/app/[locale]/(app)/dashboard/occupancy-widget", () => ({ OccupancyWidget: (p: { unitsCount: number; ownedCount: number }) => <div data-widget="occupancy">{p.unitsCount}/{p.ownedCount}</div> }));
vi.mock("@/app/[locale]/(app)/dashboard/tenant-dashboard-tabs", () => ({
  TenantDashboardTabs: (p: { overviewContent: ReactNode; tasksContent: ReactNode; operationsContent: ReactNode }) => (
    <div>{p.overviewContent}{p.tasksContent}{p.operationsContent}</div>
  ),
}));

type Result = { data?: unknown; count?: number | null; error?: { message: string } | null };
let granted = new Set<string>();
let calls: string[] = [];
let tableResults: Record<string, Result> = {};
let rpcResult: Result = { data: [], error: null };

function builder(table: string) {
  const result = () => ({ data: null, count: null, error: null, ...(tableResults[table] ?? {}) });
  const b: Record<string, unknown> = {};
  for (const m of ["select", "eq", "in", "is", "order", "limit"]) b[m] = () => b;
  b.maybeSingle = async () => result();
  b.then = (resolve: (v: unknown) => unknown) => resolve(result());
  return b;
}
vi.mock("@/lib/supabase/server", () => ({
  createClient: async () => ({
    auth: { getUser: async () => ({ data: { user: { id: "user-1" } } }) },
    from: (table: string) => { calls.push(`from:${table}`); return builder(table); },
    rpc: async (fn: string) => { calls.push(`rpc:${fn}`); return { data: null, count: null, error: null, ...rpcResult }; },
  }),
}));
vi.mock("@/lib/auth/nav-permissions", () => ({
  buildPermissionChecker: async () => (key?: string) => (key ? granted.has(key) : true),
}));

const { TenantDashboard } = await import("@/app/[locale]/(app)/dashboard/tenant-dashboard");

const org = { id: "org-1", name: "Org", default_currency: "EGP" };
const render = async () => renderToStaticMarkup(await TenantDashboard({ organization: org, locale: "en" }));
const queried = (name: string) => calls.includes(name);

const PERIOD = { id: "p1", name: "2026", start_date: "2026-01-01", end_date: "2026-12-31" };
const TB = [
  { category: "REVENUE", balance: 1234 },
  { category: "EXPENSE", balance: 234 },
];

beforeEach(() => {
  granted = new Set();
  calls = [];
  rpcResult = { data: TB, error: null };
  tableResults = {
    fiscal_periods: { data: PERIOD },
    dues: { data: [{ id: "d1", amount: 900, due_date: "2020-01-01", status: "ISSUED", unit_id: "u" }] },
    payment_allocations: { data: [] },
    payments: { data: [{ id: "pay1", receipt_number: "R-1", amount: 50, method: "CASH", payment_date: "2020-01-01", status: "POSTED" }] },
    cashier_sessions: { count: 3 },
    journal_entries: { count: 4 },
    cheques: { count: 5 },
    units_with_financials: { count: 148 },
    members: { count: 112 },
  };
});

describe("viewer without finance permissions (gate operator / technician)", () => {
  it("runs no finance query at all and never calls the trial balance", async () => {
    const html = await render();
    expect(queried("rpc:get_trial_balance")).toBe(false);
    for (const t of ["dues", "payments", "payment_allocations", "cashier_sessions", "journal_entries", "cheques", "fiscal_periods", "units_with_financials", "members"]) {
      expect(queried(`from:${t}`), t).toBe(false);
    }
    expect(html).toContain('data-state="denied"');
  });

  it("renders no financial figure that could be mistaken for a real zero", async () => {
    const html = await render();
    // Figures are rendered as data-kpi / data-mini elements; a denied section shows a panel instead.
    expect(html).not.toMatch(/data-(kpi|mini)=/);
    expect(html).not.toContain("No collections recorded yet");
    expect(html).not.toContain("No overdue dues");
    expect(html).not.toContain('data-widget="trend"');
    expect(html).not.toContain('data-widget="aging"');
    expect(html).not.toContain("No open fiscal period"); // a period banner is for people who can act on periods
  });
});

describe("accountant-like viewer (reports, dues, payments, entries)", () => {
  beforeEach(() => {
    granted = new Set(["finance.reports.read", "finance.dues.read", "finance.payments.read", "finance.entries.create"]);
  });
  it("queries and shows exactly what is permitted", async () => {
    const html = await render();
    expect(calls.filter((c) => c === "rpc:get_trial_balance")).toHaveLength(7); // the open period + 6 months
    expect(html).toContain('data-kpi="Total Revenue (EGP)"');
    expect(html).toContain("1234");
    expect(html).toContain('data-kpi="Outstanding Receivables"');
    expect(html).toContain('data-mini="Unposted entries">4');
    // finance.reports.read also opens the cheque register (cheques_select_permission); cashier sessions need cashier.* keys
    expect(queried("from:cheques")).toBe(true);
    expect(html).toContain('data-mini="Pending cheques">5');
    expect(queried("from:cashier_sessions")).toBe(false);
    expect(html).not.toContain('data-mini="Open sessions"');
    expect(queried("from:units_with_financials")).toBe(false);
  });
});

describe("partial permissions never produce partial (wrong) figures", () => {
  it("dues.read without payments.read does not show receivables: outstanding needs both", async () => {
    granted = new Set(["finance.dues.read"]);
    const html = await render();
    expect(queried("from:dues")).toBe(false);
    expect(html).not.toContain('data-kpi="Outstanding Receivables"');
    expect(html).toContain("Receivables: not available for your permissions");
  });
  it("payments.read alone shows collections but not receivables", async () => {
    granted = new Set(["finance.payments.read"]);
    const html = await render();
    expect(html).toContain('data-mini="Collected today"');
    expect(html).not.toContain('data-kpi="Outstanding Receivables"');
  });
});

describe("failures are errors, not zeros", () => {
  it("a trial-balance failure for a permitted viewer renders an error panel, not 0", async () => {
    granted = new Set(["finance.reports.read"]);
    rpcResult = { data: null, error: { message: "boom" } };
    const html = await render();
    expect(html).toContain('data-state="error"');
    expect(html).toContain('role="alert"');
    expect(html).not.toContain('data-kpi="Total Revenue (EGP)"');
    expect(html).not.toContain('data-widget="trend"');
  });
  it("a failed dues query for a permitted viewer is an error, not 'No overdue dues'", async () => {
    granted = new Set(["finance.dues.read", "finance.payments.read"]);
    tableResults.dues = { data: null, error: { message: "rls" } };
    const html = await render();
    expect(html).toContain('data-state="error"');
    expect(html).not.toContain("No overdue dues");
    expect(html).not.toContain('data-kpi="Outstanding Receivables"');
  });
});

describe("units and members use real counts, not simulated shares", () => {
  it("a viewer with property access gets the widget built from the queried active-unit counts", async () => {
    granted = new Set(["property.units.view"]);
    tableResults.units_with_financials = { count: 148 };
    tableResults.members = { count: 112 };
    const html = await render();
    expect(queried("from:units_with_financials")).toBe(true);
    expect(html).toContain('data-widget="occupancy">148/148');
  });
});
