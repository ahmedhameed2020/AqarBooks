import { describe, expect, it } from "vitest";
import { computePosition } from "@/lib/portal/statement-position";

// due 600 issued 09-01, due 09-15; advance 1000 received 09-05; 400 applied 09-08 and reversed 09-10; 300 applied 09-12
const dues = [{ id: "d1", amount: 600, issueDate: "2026-09-01", dueDate: "2026-09-15" }];
const allocations = [
  { dueId: "d1", amount: 400, appliedOn: "2026-09-08", reversedOn: "2026-09-10" },
  { dueId: "d1", amount: 300, appliedOn: "2026-09-12", reversedOn: null },
];
/** the advance as the as-of credit function reports it on a date: remaining = advance minus the applications in force then */
const advanceAsOf = (d: string) =>
  d < "2026-09-05" ? [] : [{ amount: 1000, remaining: 1000 - allocations.filter((a) => a.appliedOn <= d && (!a.reversedOn || a.reversedOn > d)).reduce((s, a) => s + a.amount, 0) }];
const at = (asOf: string) => computePosition({ asOf, dues, allocations, advances: advanceAsOf(asOf) });

describe("owner position as of a date", () => {
  it("before the receipt: the due is owed and there is no credit", () => {
    expect(at("2026-09-03")).toMatchObject({ outstanding: 600, arrears: 0, net: 600, credit: { received: 0, remaining: 0 } });
  });
  it("after the receipt: credit 1000, net -400", () => {
    expect(at("2026-09-06")).toMatchObject({ outstanding: 600, net: -400, credit: { received: 1000, applied: 0, remaining: 1000 } });
  });
  it("applying 400 lowers the due and the credit together: the net does not move", () => {
    expect(at("2026-09-09")).toMatchObject({ outstanding: 200, net: -400, credit: { applied: 400, remaining: 600 } });
  });
  it("reversing it restores both, again with the same net (nothing deducted twice)", () => {
    expect(at("2026-09-11")).toMatchObject({ outstanding: 600, net: -400, credit: { applied: 0, remaining: 1000 } });
  });
  it("a later application, and arrears once the due date has passed", () => {
    expect(at("2026-09-20")).toMatchObject({ outstanding: 300, arrears: 300, net: -400, credit: { applied: 300, remaining: 700 } });
  });
  it("the net is the same on every date from the receipt on", () => {
    const nets = ["2026-09-05", "2026-09-08", "2026-09-10", "2026-09-12", "2026-10-30"].map((d) => at(d).net);
    expect(new Set(nets)).toEqual(new Set([-400]));
  });
  it("dues issued after the date are not counted", () => {
    expect(computePosition({ asOf: "2026-08-31", dues, allocations: [], advances: [] }).outstanding).toBe(0);
  });
});

describe("a due settled by someone else's receipt (new owner after a transfer)", () => {
  const unit = [
    { id: "d1", amount: 2000, issueDate: "2026-08-01", dueDate: "2026-08-01", settled: 2000 },
    { id: "d2", amount: 800, issueDate: "2026-09-01", dueDate: "2026-09-01", settled: 0 },
  ];
  it("uses the settled amount, whoever paid: D1 is not a debt, arrears are 800 not 2,800", () => {
    expect(computePosition({ asOf: "2026-12-31", dues: unit, allocations: [], advances: [] })).toMatchObject({ outstanding: 800, arrears: 800, net: 800 });
  });
  it("without the settled amount (what owner RLS alone allowed) the same data would have said 2,800", () => {
    const blind = unit.map(({ settled, ...d }) => ({ ...d, _: settled }));
    expect(computePosition({ asOf: "2026-12-31", dues: blind.map(({ _, ...d }) => d), allocations: [], advances: [] }).outstanding).toBe(2800);
  });
});
