/**
 * The owner's position AS OF a date, from dues, effective allocations and customer-advance receipts.
 *
 *   outstanding = what the issued dues still owe on that date (receipt allocations AND credit applications both reduce it)
 *   credit      = advances received up to that date, minus the applications in force on it
 *   net         = outstanding - credit.remaining
 *
 * Applying credit lowers `outstanding` and `credit.remaining` by the same amount, and reversing it raises both: the net never moves.
 * A receipt is counted once, either as an allocation to a due or as credit, so nothing is deducted twice.
 */
const r4 = (n: number) => Math.round(n * 10_000) / 10_000;

/** `settled`, when given, is the amount settled on the due as of the date by ANY receipt in force (own_statement_dues); otherwise it is summed from `allocations`. */
export type PositionDue = { id: string; amount: number; issueDate: string; dueDate: string; settled?: number };
export type PositionAllocation = { dueId: string; amount: number; appliedOn: string; reversedOn?: string | null };
export type PositionAdvance = { amount: number; remaining: number };
export type OwnPosition = {
  asOf: string;
  outstanding: number;
  arrears: number;
  credit: { received: number; applied: number; remaining: number };
  net: number;
};

/** `allocations` must already be limited to the receipts in force on `asOf`; reversal/application dates are re-checked here. */
export function computePosition(input: { asOf: string; dues: PositionDue[]; allocations: PositionAllocation[]; advances: PositionAdvance[] }): OwnPosition {
  const { asOf } = input;
  const inForce = input.allocations.filter((a) => a.appliedOn <= asOf && (!a.reversedOn || a.reversedOn > asOf));
  const allocated = new Map<string, number>();
  for (const a of inForce) allocated.set(a.dueId, (allocated.get(a.dueId) ?? 0) + a.amount);

  let outstanding = 0;
  let arrears = 0;
  for (const d of input.dues) {
    if (d.issueDate > asOf) continue;
    const left = Math.max(0, r4(d.amount - (d.settled ?? allocated.get(d.id) ?? 0)));
    outstanding += left;
    if (d.dueDate < asOf) arrears += left;
  }
  const received = input.advances.reduce((s, a) => s + a.amount, 0);
  const remaining = input.advances.reduce((s, a) => s + a.remaining, 0);
  return {
    asOf,
    outstanding: r4(outstanding),
    arrears: r4(arrears),
    credit: { received: r4(received), applied: r4(received - remaining), remaining: r4(remaining) },
    net: r4(outstanding - remaining),
  };
}
