import { createClient } from "@/lib/supabase/server";
import { computePosition, type OwnPosition } from "@/lib/portal/statement-position";

type Client = Awaited<ReturnType<typeof createClient>>;

/**
 * The signed-in owner's position as of a date.
 *  - dues and the amount SETTLED on each (by any receipt in force, an amount only) come from own_statement_dues, so a due that a
 *    previous owner's receipt paid is not counted as a new debt, and the dues of a member whose ownership ended stay on their statement;
 *  - the owner's own advance credit comes from payment_credit_balances_as_of (member-scoped).
 */
export async function loadOwnPosition(supabase: Client, organizationId: string, memberId: string, asOf: string): Promise<OwnPosition | null> {
  const [{ data: dues, error: duesError }, { data: credit, error: creditError }] = await Promise.all([
    supabase.rpc("own_statement_dues", { p_org: organizationId, p_as_of: asOf }),
    supabase.rpc("payment_credit_balances_as_of", { p_org: organizationId, p_as_of: asOf }),
  ]);
  if (duesError || creditError) return null;
  const myCredit = (credit ?? []).filter((c) => c.member_id === memberId);
  return computePosition({
    asOf,
    dues: (dues ?? []).map((d) => ({ id: d.due_id, amount: Number(d.amount), issueDate: d.issue_date, dueDate: d.due_date, settled: Number(d.settled_amount) })),
    allocations: [],
    advances: myCredit.map((c) => ({ amount: Number(c.advance_amount), remaining: Number(c.remaining_amount) })),
  });
}
