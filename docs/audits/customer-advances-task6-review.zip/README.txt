Customer advances: Task 5 round 2 + Task 6 (B1-B8, regression, migrations F/G/H). See files/docs/audits/phase3-evidence/task6-run-record.md.
Local only; nothing committed, pushed or deployed.
