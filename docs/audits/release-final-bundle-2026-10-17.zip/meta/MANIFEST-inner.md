# Inner manifest (content of the bundle without its own hash)
* base commit 5d2804f3ac2979872e8f657da645ad5ef4c8852a on fix/phase1-financial-report-authz
* candidate groups {"A1": 27, "A2": 79, "A4": 113, "D1": 15, "T1": 22}
* migration 20261018100000_deposit_account_cash_or_bank.sql 12,701 bytes SHA-256 add8a244a189b58f548db0d9a6ed6061556504f4326f1b8276349f7b443c1b99
* deleted tracked files 0, renamed 0
* secret-pattern hits 0
* the outer MANIFEST.md and SHA256SUMS.txt (with the zip's own hash) sit beside the zip in docs/audits/release-final-bundle-manifest/
