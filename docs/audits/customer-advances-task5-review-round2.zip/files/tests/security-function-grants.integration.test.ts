/**
 * Phase 1 security regression guard — function EXECUTE grant posture.
 *
 * WHY THIS EXISTS
 * During Phase 1, migration 4 (20260820190630_phase1_revoke_anon_function_execute)
 * revoked EXECUTE from PUBLIC and anon but issued an unconditional
 * `GRANT EXECUTE ... TO authenticated` in the same loop. That granted
 * `authenticated` direct access to nine internal functions it had never had,
 * including post_payment_internal and post_journal_entry_internal -- the
 * unguarded internals that record_payment and post_journal_entry exist to
 * wrap. Any signed-in user could have bypassed the RBAC guard that migration 3
 * had just hardened. It was caught only by hand-diffing two security-advisor
 * runs (169 -> 178) and repaired by migration 5.
 *
 * A COUNT CHECK IS NOT SUFFICIENT. The total can remain 169 while a harmless
 * function is swapped for a dangerous one. These tests therefore assert SET
 * EQUALITY against a named baseline, plus an explicit denylist for the
 * internals that must never be client-callable under any circumstances.
 *
 * This suite is READ-ONLY. It creates no organizations, payments or journal
 * entries and is safe to run against any environment, including production.
 *
 * If a test here fails, do not edit the baseline to make it pass. Establish
 * first whether the grant change was intended; only then move the name
 * between the allowlist and the denylist, in the same commit as the migration
 * that caused it.
 */
import { describe, it, expect, beforeAll } from "vitest";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { config } from "dotenv";
import { execFileSync } from "node:child_process";

config({ path: ".env.local" });

function resolveSupabaseCredentials() {
  try {
    const output = execFileSync("supabase", ["status", "-o", "env", ...(process.env.LOCAL_SUPABASE_WORKDIR ? ["--workdir", process.env.LOCAL_SUPABASE_WORKDIR] : [])], {
      cwd: process.cwd(),
      encoding: "utf8",
      stdio: ["ignore", "pipe", "ignore"],
    });
    const env: Record<string, string> = {};
    for (const line of output.split(/\r?\n/)) {
      const match = line.match(/^([A-Z0-9_]+)="?(.*?)"?$/);
      if (match) env[match[1]] = match[2];
    }
    if (env.API_URL?.startsWith("http://127.0.0.1:") && env.SERVICE_ROLE_KEY) {
      return { url: env.API_URL, serviceKey: env.SERVICE_ROLE_KEY };
    }
  } catch {
    // Fall back to .env.local for the existing read-only guard behavior.
  }

  return {
    url: process.env.NEXT_PUBLIC_SUPABASE_URL!,
    serviceKey: process.env.SUPABASE_SERVICE_ROLE_KEY!,
  };
}

/**
 * Internal functions that must NEVER be executable by `anon` or
 * `authenticated`. Each is either an unguarded internal wrapped by a
 * permission-checked public function, a credential accessor, or an
 * audit-trail writer. Reached only from inside other SECURITY DEFINER
 * functions (which run as owner) or via the service-role client.
 */
const INTERNAL_FUNCTIONS_NEVER_CLIENT_CALLABLE = [
  "audit_gate_authentication_failure", // service-only post-failure audit writer
  "gate_scan_telemetry", // tenant-scoped server aggregate
  "gate_notification_admitted", "enqueue_gate_notification_impl", "deliver_gate_notification_impl", "process_gate_notifications_impl",
  "audit_gate_reconciliation", "reject_gate_scan_device_mutation", // trigger-only evidence controls
  "process_visitor_gate_scan_core", // canonical core admitted only via gated wrappers
  "require_gate_completion", // internal locked rollout admission
  "require_gate_scan_actor", // gate authorization before rollout state lookup
  "guard_gate_completion_insert", // trigger-only completion admission
  "detect_gate_long_stays", // service-only bounded detector
  "gate_supervision_context", // internal permission/context helper
  "gate_supervision_append_only", // trigger-only immutable evidence guard
  // Phase 1 (20261009120000): unguarded finance helpers, reachable only from SECURITY DEFINER callers / service_role
  "due_outstanding",
  "creditable_remaining",
  "depreciable_remaining",
  "depreciation_for_period",
  "resolve_due_buyer",
  "project_wip_summary",
  "check_fx_readiness",
  "check_asset_disposal_readiness",
  "resolve_input_tax_account",
  "resolve_output_tax_account",
  "get_exchange_rate",
  "convert_to_base",
  "compute_input_tax_split",
  "post_payment_internal", // wrapped by record_payment
  "post_journal_entry_internal", // wrapped by post_journal_entry
  "create_journal_entry_internal",
  "get_payment_provider_credentials", // payment provider secrets
  "append_financial_audit_event", // forging audit entries
  "record_online_payment", // service-role webhook path
  "enqueue_online_payment_event", // service-role durable webhook intake
  "claim_online_payment_events", // service-role retry worker claim
  "complete_online_payment_event", // service-role event state transition
  "online_payment_events_append_only", // trigger-only immutability guard
  "mark_online_payment_checkout_created", // service-role checkout finalization
  "run_lease_rent_generation", // service-role sweep
  "promote_scheduled_lease_renewals", // service-role lease activation boundary
  "run_lease_expiry_alerts", // service-role lease-expiry notification sweep
  "expire_stale_member_invitations", // service-role sweep
  "expire_stale_online_payment_transactions", // service-role sweep
  "assert_maintenance_status_transition", // internal validator wrapped by maintenance mutation RPCs
  "maintenance_attachment_extension", // canonical path helper
  "maintenance_request_accepts_attachments", // request state helper
  "seed_default_maintenance_categories", // trigger helper, not a direct client API
  "assert_work_order_status_transition", // internal validator wrapped by work order mutation RPCs
  "assert_work_order_cost_currency", // internal cost currency guard wrapped by cost mutation RPCs
  "validate_work_order_assignee", // internal assignment validator
  "insert_work_order_update", // operational evidence writer
  "audit_work_order_action", // platform audit writer
  "audit_work_order_cost_action", // platform audit writer
  "transition_work_order", // wrapped by narrow lifecycle RPCs
  "normalize_vehicle_plate", // helper wrapped by vehicle mutation RPCs
  "create_notification_once", // internal idempotent notification writer
  "notify_maintenance_request_created", // trigger helper
  "notify_maintenance_request_update", // trigger helper
  "notify_work_order_lifecycle", // trigger helper
  "notify_owner_charge_created", // trigger helper
  "notify_visitor_invitation_lifecycle", // trigger helper
  "notify_access_event_allowed", // trigger helper
  "notify_due_created", // trigger helper
  "notify_payment_confirmed", // trigger helper
  "notify_amenity_booking_lifecycle", // trigger helper
  "enforce_opening_balance_current_unit_link", // trigger-only current-tenancy guard
] as const;

const ANON_EXECUTABLE_ALLOWLIST = new Set<string>([
  "guard_role_permissions_scope",
  "guard_roles_security",
  "guard_user_role_assignments_security",
  "is_demo_organization",
  "is_demo_principal",
]);

/**
 * Approved baseline: the exact set of SECURITY DEFINER application functions
 * that `authenticated` may execute, as of Phase 1 close (2026-08-20,
 * migrations 20260820190233-6). 169 entries.
 */
const AUTHENTICATED_SECDEF_ALLOWLIST = new Set<string>([
  "create_gate_manual_exception", "approve_gate_manual_exception", "reconcile_visitor_access_state",
  "list_gate_current_visitors", "list_gate_access_evidence",
  "set_gate_long_stay_policy",
  "gate_completion_enabled", "set_gate_completion_policy",
  "abort_maintenance_attachment_upload",
  "accept_member_invitation", "accrue_commission", "activate_unit_lease", "add_organization_member",
  "approve_due_type_revenue_nature", "approve_expense_account_input_tax",
  "approve_onboarding_request", "approve_purchase_order", "approve_tax_rule", "archive_unit", "assign_subscription",
  "auto_match_bank_statement", "cancel_installment_plan", "cancel_supplier_invoice", "cancel_unit_lease",
  "capitalise_project_cost", "check_einvoice_emission_readiness",
  "check_input_tax_readiness", "check_installment_plan_completion",
  "cancel_own_maintenance_request", "check_tax_enforcement_readiness", "claim_einvoice_document", "clear_incoming_cheque",
  "clone_chart_of_accounts_template", "close_cashier_session",
  "complete_unit_handover", "compute_service_charge_allocations",
  "create_cashbox", "create_fiscal_year", "create_installment_plan",
  "create_journal_entry", "create_member_invitation", "create_organization",
  "create_online_payment_checkout_transaction",
  "create_maintenance_request",
  "create_purchase_order", "create_purchase_request",
  "create_resort", "create_tax_rule_draft", "create_unit_lease", 
  "current_member_id", "decide_purchase_request", "delete_resort", 
  "disable_payment_provider", "dispose_fixed_asset",
  "due_ids_have_pending_online_checkout", "enable_payment_provider",
  "begin_maintenance_attachment_upload",
  "guard_role_permissions_scope", "guard_roles_security", "guard_user_role_assignments_security",
  "is_demo_organization", "is_demo_principal",
  "end_unit_lease", "ensure_opening_balance_due_type", "finalize_bank_reconciliation", "generate_lease_rent_dues",
  "finalize_maintenance_attachment_upload",
  "generate_recurring_dues", "get_account_ledger", "get_bank_match_candidates",
  "get_bank_reconciliation_summary", "get_cash_flow_statement", "get_cash_position",
  "get_einvoice_source_for_credit_note", "get_einvoice_source_for_due", "get_entitlement",
  "get_journal_entry_for_view", "get_lease_deposit_summary",
  "get_own_organization_display", "get_payment_provider_settings_credentials",
  "get_service_charge_allocations", "get_tax_decision_coverage", "get_trial_balance", "get_trial_balance_with_opening", "get_audit_actor_names",
  "get_navigation_permissions", "get_unrecognized_dues_summary", "handle_new_user", "has_any_permission", "has_financial_permission", "has_permission",
  "is_current_member_unit_owner",
  "is_org_member", "is_org_participant", "is_platform_admin", "is_resort_member", "issue_credit_note", "issue_dues",
  "issue_service_charge_levy", "link_unit_ownership", "list_catalogue_items", "list_credit_notes",
  "list_creditable_dues", "list_due_type_catalogue_links", "list_due_type_tax_mappings",
  "list_dunning_candidates", "list_dunning_notices", "list_exchange_rates", "list_fixed_assets",
  "list_projects", "list_tax_enforcement_lapses", "log_coa_change",
  "maintenance_attachment_can_delete_object", "maintenance_attachment_can_select_object",
  "maintenance_attachment_can_upload_object", "maintenance_attachment_member_can_read",
  "maintenance_attachment_staff_can_manage", "maintenance_attachment_staff_can_read",
  "maintenance_module_enabled", "maintenance_request_staff_can_read",
  "unit_experience_enabled", "vehicle_staff_can_read", "vehicle_staff_can_manage",
  "vehicle_member_can_read", "create_vehicle", "update_vehicle_staff",
  "deactivate_own_vehicle", "mark_notification_read", "mark_all_notifications_read",
  "get_unit_timeline",
  "amenity_booking_enabled", "amenity_staff_can_read", "amenity_staff_can_manage",
  "create_amenity", "update_amenity", "set_amenity_active", "create_amenity_booking",
  "cancel_own_amenity_booking", "decide_amenity_booking",
  "lease_lifecycle_enabled", "lease_renewal_staff_can_read", "lease_renewal_staff_can_manage",
  "notification_feature_enabled",
  "request_lease_renewal", "decide_lease_renewal", "get_owned_unit_lease_renewal_status",
  "create_visitor_invitation", "revoke_visitor_invitation", "validate_visitor_pass_token",
  "visitor_invitation_member_can_read", "visitor_invitation_staff_can_manage",
  "visitor_invitation_staff_can_read", "visitor_management_enabled",
  "create_gate", "gate_operations_enabled", "gate_staff_can_manage", "gate_staff_can_scan",
  "gate_staff_can_view", "gate_staff_can_view_access_events", "process_visitor_gate_scan",
  "update_gate", "create_gate_device_enrollment", "redeem_gate_device_enrollment",
  "release_gate_device", "lookup_gate_reconciliation_invitation", "export_gate_current_visitors",
  "record_gate_connectivity_incident", "revoke_gate_device", "verify_gate_device_binding",
  "add_work_order_update", "assign_work_order", "cancel_work_order", "complete_work_order",
  "create_work_order", "resume_work_order", "schedule_work_order", "start_work_order",
  "wait_work_order", "work_order_member_can_read",
  "work_order_staff_can_assign", "work_order_staff_can_complete", "work_order_staff_can_manage",
  "work_order_staff_can_read",
  "add_work_order_cost", "charge_work_order_cost_to_owner", "post_work_order_cost_as_expense",
  "post_work_order_cost_as_supplier_invoice", "update_unposted_work_order_cost",
  "void_unposted_work_order_cost", "work_order_cost_staff_can_charge_owner",
  "work_order_cost_member_can_read_due", "work_order_cost_staff_can_manage", "work_order_cost_staff_can_post",
  "work_order_cost_staff_can_read",
  "open_cashier_session", "organization_is_active", "pay_commission", "post_depreciation_for_period",
  "post_fx_difference", "post_journal_entry", "post_supplier_invoice",
  "post_supplier_invoice_in_currency", "preview_generate_recurring_dues", 
  "raise_dunning_notices", "recognize_pending_dues", "reconcile_cashier_session",
  "record_dunning_delivery", "record_einvoice_attempt", "record_expense", "record_incoming_cheque",
  "record_input_tax_decision", "record_lease_deposit_event", "record_member_opening_balance", "record_payment",
  "record_payment_provider_verification", "record_supplier_payment", "record_tax_decision_for_due",
  "reject_onboarding_request", "release_project_wip", "reopen_bank_reconciliation",
  "resolve_tax_rule",
  "restore_unit", "reverse_journal_entry", "reverse_tax_decision",
  "revoke_due_type_revenue_nature_approval", "schedule_unit_handover",
  "set_asset_disposal_accounts", "set_cheque_status", "set_due_type_catalogue_item",
  "set_due_type_revenue_nature", "set_einvoice_profile_enabled", "set_einvoice_profile_verification",
  "set_expense_account_input_tax", "set_fiscal_period_status", "set_fx_difference_accounts",
  "set_input_tax_account", "set_member_tax_identity", "set_organization_status",
  "set_output_tax_account", "set_purchase_order_status", "set_tax_enforcement",
  "set_unit_lease_billing_recipient", "settle_supplier_invoice_fx_difference",
  "submit_journal_entry_for_review", "supersede_tax_rule", "sync_member_primary_phone",
  "trg_credit_note_immutable", "trg_dues_post_to_ledger", "trg_dues_tax_decision",
  "trg_input_tax_decision_immutable", "trg_members_tax_identity_changed",
  "trg_organizations_tax_identity_changed", "update_maintenance_request_staff", "update_resort", "update_unit", "upsert_catalogue_item",
  "upsert_einvoice_profile", "upsert_payment_provider_settings", "verify_financial_audit_chain",
  "void_payment", "void_supplier_payment",
  // Phase 2b: approved receivable account (read: finance.dues.issue | finance.accounts.manage; set: finance.accounts.manage)
  "get_default_receivable_account", "set_default_receivable_account",
  // Phase 3b (20261017100100) customer advances. Reviewed: each checks its own permission and organization scope inside
  //   set_default_customer_advance_account  finance.accounts.manage
  //   record_advance_payment                receivables.payments.create (property scoped)
  //   apply_payment_credit / reverse_credit_application   receivables.allocations.manage (property scoped)
  // The internal helpers (post_advance_payment_internal, recompute_due_payment_status, assert_posting_period,
  // credit_request_hash, normalize_credit_allocations) are NOT executable by authenticated and stay off this list.
  "set_default_customer_advance_account", "record_advance_payment", "apply_payment_credit", "reverse_credit_application",
  // Phase 3c (20261017100200). Reviewed: payment_receipt_entry_status returns ONE status word for a receipt the caller may
  // already read (finance.payments.read in its organization, or the receipt's own member; a backend caller with no end user is
  // trusted). The security-invoker views and as-of functions need it so an owner's session can tell a posted receipt from a draft
  // without any access to journal_entries. credit_min_available_from / due_min_outstanding_from stay internal.
  "payment_receipt_entry_status",
  // Phase 3d (20261017100300). Reviewed: the two as-of functions became DEFINER so that an owner's session can rebuild a past date
  // that includes a receipt voided later (the payments RLS hides REVERSED receipts from the owner). They scope the rows themselves
  // (finance.payments.read for the organization; otherwise the caller's own member and only while the organization is active) and
  // return amounts only: no journal entry, line or account. due_effective_paid stays internal.
  "payment_allocations_as_of", "payment_credit_balances_as_of",
  // Phase 3f (20261017100500). Reviewed: the owner's statement needs receipts voided later and credit applications that owner RLS
  // hides (payments_select_own / payment_allocations_select_own expose POSTED receipts only). Each returns ONLY the caller's own rows
  // (p.member_id = current_member_id(), organization active, receipt entry POSTED/REVERSED): no staff and no trusted-backend branch, so
  // staff, another organization's owner and a foreign organization id get nothing. Amounts, dates and ids; no entry, line, account or reason.
  "own_statement_receipts", "own_credit_application_lines",
]);

/**
 * Owner portal (migration 20261004120000_owner_portal_access.sql). These ten are deliberately callable by
 * `authenticated` because the app calls them with the signed-in user's own session; they are NOT on this list
 * for convenience. Each was reviewed (signature, SECURITY DEFINER search_path, guard) and exercised with real
 * sessions in tests/owner-portal-functions-authz.integration.test.ts:
 *   staff, gated by the member's own organization + key (42501 otherwise, identical error for unknown ids):
 *     members.portal.invite  -> get_member_portal_access, request_member_activation, revoke_member_activation,
 *                               begin_member_temp_access, finish_member_temp_access
 *     members.portal.manage  -> suspend_member_portal, reactivate_member_portal, begin_member_signout
 *   self-service, acting only on members.user_id = auth.uid():  my_portal_access, complete_portal_first_login
 * anon cannot execute any of them, and the tables behind them have RLS with no policies and no client grants.
 * If one of these changes its guard, change that test first.
 */
const OWNER_PORTAL_FUNCTIONS = [
  "get_member_portal_access", "request_member_activation", "revoke_member_activation",
  "begin_member_temp_access", "finish_member_temp_access",
  "suspend_member_portal", "reactivate_member_portal", "begin_member_signout",
  "my_portal_access", "complete_portal_first_login",
] as const;
for (const fn of OWNER_PORTAL_FUNCTIONS) AUTHENTICATED_SECDEF_ALLOWLIST.add(fn);

type InventoryRow = {
  function_name: string;
  is_security_definer: boolean;
  anon_can_execute: boolean;
  authenticated_can_execute: boolean;
};

describe("Security invariant — function EXECUTE grants", () => {
  let admin: SupabaseClient;
  let inventory: InventoryRow[];

  beforeAll(async () => {
    const { url, serviceKey } = resolveSupabaseCredentials();
    admin = createClient(url, serviceKey, { auth: { persistSession: false } });

    const { data, error } = await admin.rpc("security_function_grant_inventory");
    expect(error, `inventory RPC failed: ${error?.message}`).toBeNull();
    inventory = (data ?? []) as InventoryRow[];
    expect(inventory.length).toBeGreaterThan(0);
  });

  it("no application function is executable by anon", () => {
    const anonExecutable = inventory
      .filter((r) => r.anon_can_execute && !ANON_EXECUTABLE_ALLOWLIST.has(r.function_name))
      .map((r) => r.function_name)
      .sort();

    expect(
      anonExecutable,
      `anon must not execute any application function. Offenders: ${anonExecutable.join(", ")}`,
    ).toEqual([]);
  });

  it("internal functions are never executable by anon or authenticated", () => {
    const offenders = inventory
      .filter(
        (r) =>
          (INTERNAL_FUNCTIONS_NEVER_CLIENT_CALLABLE as readonly string[]).includes(r.function_name) &&
          (r.anon_can_execute || r.authenticated_can_execute),
      )
      .map((r) => r.function_name)
      .sort();

    expect(
      offenders,
      `These are unguarded internals / credential accessors and must never be client-callable. ` +
        `Reaching post_payment_internal or post_journal_entry_internal directly bypasses the RBAC ` +
        `guard on record_payment / post_journal_entry entirely. Offenders: ${offenders.join(", ")}`,
    ).toEqual([]);
  });

  it("every internal function on the denylist still exists (denylist has not gone stale)", () => {
    const present = new Set(inventory.map((r) => r.function_name));
    const missing = (INTERNAL_FUNCTIONS_NEVER_CLIENT_CALLABLE as readonly string[])
      .filter((fn) => !present.has(fn))
      .sort();

    expect(
      missing,
      `Denylisted functions no longer exist, so the guard above is silently vacuous for them: ${missing.join(", ")}`,
    ).toEqual([]);
  });

  it("authenticated-executable SECURITY DEFINER set matches the approved baseline exactly", () => {
    const actual = new Set(
      inventory
        .filter((r) => r.is_security_definer && r.authenticated_can_execute)
        .map((r) => r.function_name),
    );

    const added = [...actual].filter((fn) => !AUTHENTICATED_SECDEF_ALLOWLIST.has(fn)).sort();
    const removed = [...AUTHENTICATED_SECDEF_ALLOWLIST].filter((fn) => !actual.has(fn)).sort();

    // Reported separately: a widened surface is a security regression, while a
    // narrowed one is usually an intentional tightening that still needs the
    // baseline updated in the same commit.
    expect(
      added,
      `NEW functions became authenticated-executable and are not in the approved baseline. ` +
        `This is how the migration-4 regression happened. Confirm each is intended, then add it ` +
        `to the allowlist in the same commit as its migration: ${added.join(", ")}`,
    ).toEqual([]);

    expect(
      removed,
      `Functions in the baseline are no longer authenticated-executable. If that was intended, ` +
        `remove them from the allowlist in the same commit: ${removed.join(", ")}`,
    ).toEqual([]);

    expect(actual.size).toBe(AUTHENTICATED_SECDEF_ALLOWLIST.size);
  });
});
