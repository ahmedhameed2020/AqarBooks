import { setRequestLocale } from "next-intl/server";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getPortalMemberContext } from "@/lib/auth/portal-member";
import type { Locale } from "@/i18n/routing";
import type { DueDbRow } from "@/lib/portal/row-types";
import { loadOwnPosition } from "@/lib/portal/own-position";
import { PortalStatementClient, type PortalStatementMovement } from "./portal-statement-client";

type PaymentRow = {
  payment_id: string;
  amount: number;
  payment_date: string;
  receipt_no: string | null;
  receipt_number: number | null;
  unit_id: string | null;
  status: string;
  reversed_on: string | null;
};

export default async function PortalStatementPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale as Locale);
  const isAr = locale === "ar";

  const supabase = await createClient();
  const ctx = await getPortalMemberContext();
  if (ctx.status !== "ok") redirect("/portal/login");

  const { member } = ctx;

  const [
    { data: orgDisplay },
    { data: duesData, error: duesError },
    { data: paymentsData, error: paymentsError },
    { data: memoData },
    { data: applicationData, error: applicationError },
    { data: unitsData, error: unitsError },
  ] = await Promise.all([
    supabase.rpc("get_own_organization_display").maybeSingle(),
    supabase
      .from("dues")
      .select("id, amount, issue_date, due_date, description, status, units(code)")
      .order("issue_date", { ascending: false }),
    // History-bounded reads: owner RLS only exposes POSTED receipts, so a receipt voided later would vanish from the periods in which it
    // really reduced the balance. These two functions return only the signed-in owner's own rows (see migration 20261017100500).
    supabase.rpc("own_statement_receipts", { p_org: member.organization_id }),
    supabase.from("payments").select("id, memo").eq("member_id", member.id),
    supabase.rpc("own_credit_application_lines", { p_org: member.organization_id }),
    supabase.from("units_with_financials").select("id, code"),
  ]);

  if (duesError) console.error("[PortalStatementPage] dues query failed:", duesError.message);
  if (paymentsError)
    console.error("[PortalStatementPage] payments query failed:", paymentsError.message);
  if (applicationError) console.error("[PortalStatementPage] credit application lines failed:", applicationError.message);
  if (unitsError) console.error("[PortalStatementPage] units query failed:", unitsError.message);

  // payments.unit_id is resolved against a separate units read rather than a
  // PostgREST embed: the embed would add a join whose FK naming the portal has
  // no other reason to depend on, and the member's unit list is a handful of
  // rows either way.
  const unitCodeById = new Map<string, string>(
    ((unitsData ?? []) as { id: string; code: string }[]).map((u) => [u.id, u.code]),
  );

  const dues = ((duesData ?? []) as unknown as DueDbRow[]).filter((d) => d.status !== "VOID");
  const payments = (paymentsData ?? []) as unknown as PaymentRow[];
  const memoById = new Map(((memoData ?? []) as { id: string; memo: string | null }[]).map((m) => [m.id, m.memo]));

  // Credit applications and their reversals, shown as two separate informational lines (net effect on the balance: zero), each at
  // its own date. The reader returns applications of receipts voided later too, so the history stays complete.
  const receiptRef = new Map(payments.map((p) => [p.payment_id, p.receipt_no || (p.receipt_number ? `REC-${p.receipt_number}` : null)]));
  const dueById = new Map(dues.map((d) => [d.id, d]));
  const infoLines: PortalStatementMovement[] = (applicationData ?? []).flatMap((a) => {
    const due = dueById.get(a.due_id);
    const what = due?.description ?? (isAr ? "مطالبة" : "charge");
    const base = { unitCode: due?.units?.code ?? null, reference: receiptRef.get(a.payment_id) ?? null, amount: Number(a.amount) };
    const lines: PortalStatementMovement[] = [
      { ...base, id: `app-${a.allocation_id}`, date: a.applied_on, kind: "APPLICATION", description: isAr ? `تطبيق رصيد مقدم على: ${what}` : `Advance credit applied to: ${what}` },
    ];
    if (a.reversed_on) lines.push({ ...base, id: `rev-${a.allocation_id}`, date: a.reversed_on, kind: "REVERSAL", description: isAr ? `عكس تطبيق الرصيد على: ${what}` : `Credit application reversed: ${what}` });
    return lines;
  });

  // A voided receipt stays a payment on its own date and is reversed by a separate financial movement dated at the actual reversal
  // entry, so every running balance before that date still includes it and every one after it does not.
  const receiptLines: PortalStatementMovement[] = payments.flatMap((p) => {
    const ref = p.receipt_no || (p.receipt_number ? `REC-${p.receipt_number}` : null);
    const unitCode = p.unit_id ? (unitCodeById.get(p.unit_id) ?? null) : null;
    const lines: PortalStatementMovement[] = [
      {
        id: `pay-${p.payment_id}`, date: p.payment_date, kind: "PAYMENT", unitCode, reference: ref, amount: Number(p.amount),
        description: memoById.get(p.payment_id)?.trim() || (isAr ? "سند سداد معتمد" : "Posted receipt"),
      },
    ];
    if (p.status === "REVERSED" && p.reversed_on) {
      lines.push({
        id: `payrev-${p.payment_id}`, date: p.reversed_on, kind: "PAYMENT_REVERSAL", unitCode, reference: ref, amount: Number(p.amount),
        description: isAr ? "عكس سند السداد (إلغاء الإيصال)" : "Receipt reversed (voided)",
      });
    }
    return lines;
  });

  const today = new Date().toISOString().slice(0, 10);
  const position = await loadOwnPosition(supabase, member.organization_id, member.id, today);

  const movements: PortalStatementMovement[] = [
    ...dues.map((d) => ({
      id: `due-${d.id}`,
      date: d.issue_date,
      kind: "CHARGE" as const,
      description: d.description ?? (isAr ? "استحقاق مالي دوري" : "Periodic due"),
      unitCode: d.units?.code ?? null,
      reference: null,
      amount: Number(d.amount),
    })),
    ...receiptLines,
    ...infoLines,
  ]
    // Oldest first: a running balance only reads as proof if it accumulates in
    // the direction time moves. The client reverses for display when asked.
    .sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id));

  return (
    <PortalStatementClient
      position={position}
      organizationName={orgDisplay?.name ?? "AqarBooks"}
      currency={orgDisplay?.default_currency ?? "EGP"}
      memberName={member.full_name ?? ""}
      movements={movements}
      unitCodes={[...new Set(movements.map((m) => m.unitCode).filter((c): c is string => !!c))].sort()}
      locale={locale}
    />
  );
}
