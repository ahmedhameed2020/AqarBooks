import { createClient } from "@/lib/supabase/server";
import { computePosition, type OwnPosition } from "@/lib/portal/statement-position";

type Client = Awaited<ReturnType<typeof createClient>>;

/**
 * The signed-in owner's position as of a date. Everything comes from the as-of functions, which already limit a portal caller to
 * their own receipts and handle receipts reversed before/after the date; dues are read through the owner's own RLS.
 */
export async function loadOwnPosition(supabase: Client, organizationId: string, memberId: string, asOf: string): Promise<OwnPosition | null> {
  const [{ data: dues, error: duesError }, { data: allocations, error: allocError }, { data: credit, error: creditError }] = await Promise.all([
    supabase.from("dues").select("id, amount, issue_date, due_date, status").neq("status", "VOID"),
    supabase.rpc("payment_allocations_as_of", { p_org: organizationId, p_as_of: asOf }),
    supabase.rpc("payment_credit_balances_as_of", { p_org: organizationId, p_as_of: asOf }),
  ]);
  if (duesError || allocError || creditError) return null;
  const myCredit = (credit ?? []).filter((c) => c.member_id === memberId);
  return computePosition({
    asOf,
    dues: (dues ?? []).map((d) => ({ id: d.id, amount: Number(d.amount), issueDate: d.issue_date, dueDate: d.due_date })),
    allocations: (allocations ?? []).map((a) => ({ dueId: a.due_id, amount: Number(a.amount), appliedOn: a.applied_on })),
    advances: myCredit.map((c) => ({ amount: Number(c.advance_amount), remaining: Number(c.remaining_amount) })),
  });
}
