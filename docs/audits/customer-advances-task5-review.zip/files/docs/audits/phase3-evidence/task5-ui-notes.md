# Task 5 — customer-advances UI (review notes)

Local only: isolated clean stack (API :55321), production build served on :3100. Nothing committed, pushed, deployed; the development database was not touched.

## What the screens do
* **Record receipt dialog** — "Pay a due" / "Advance, no due". The excess over a due is stated and must be confirmed; ONLINE is refused for advances; the period follows the payment date.
* **Payments register** — advance badge with the unit, credit left, "stranded" badge, **Credit** button (apply / reverse dialog).
* **Advance-account card** — inside the receipts page (no new settings page). Nothing is pre-selected: the approver must choose a liability account.
* **Unit page** — credit card; **payments table** — credit applications marked (reversed ones too); **dunning** — "holds credit" badge; **owner statement** — note that unapplied advances are not collected revenue; **receipt PDF** — "Advance credit" box.
* **Portal statement** — see below.

## Corrections made after the first screens were reviewed
1. **Default account choice** — the card used to pre-select the first liability account ("2100 Accounts Payable – Suppliers"), which would have been a silent wrong default. It now starts empty and the Approve button stays disabled until the owner picks one.
2. **Currency overlap** — in the receipt dialog the amount field is `dir="ltr"` while the currency label was anchored with logical `end-0`; in Arabic (RTL) the label sat on top of the digits. Both now use physical `right-0` / `pr-12`.

## Portal statement (per the spec)
Primary cards, **as of the end of the filter** (today when it is empty): **Arrears**, **Available credit**, **Net**.
`net = open dues − available credit`. Received / applied / left is a one-line detail under the cards, not a replacement.

Applying credit and reversing it appear as **two separate, dated information lines** (`APPLICATION`, `REVERSAL`) with a net effect of zero on the running balance; the debit/credit columns show "—" for them. They are excluded from the PDF; the Excel export lists them with empty debit/credit.

Source of the numbers: `payment_allocations_as_of` + `payment_credit_balances_as_of` (security-definer, member-scoped) and the owner's own dues, combined by the pure function `lib/portal/statement-position.ts`. The only direct read of `payment_allocations` is for the information lines (whitelisted in `tests/payment-allocation-readers-guard.test.ts` with its reason).

## Proof
Scenario (browser, Arabic and English): due 600 issued 09-01 / due 09-15; advance 1000 on 09-05; apply 400 on 09-08; reverse it on 09-10; apply 300 on 09-12.

| end of filter | arrears | credit | net |
|---|---|---|---|
| 2026-09-03 | 0 | 0 | 600 |
| 2026-09-06 | 0 | 1000 | −400 |
| 2026-09-09 | 0 | 600 | −400 |
| 2026-09-11 | 0 | 1000 | −400 |
| 2026-09-20 | 300 | 700 | −400 |

Changing the end date changes the figures; from the receipt on, the net is −400 on every date, so application and reversal move money between the due and the credit and never deduct twice. The ledger's own running balance agrees (−400). Unit test: `tests/portal-statement-position.test.ts` (7 tests); browser: `tests/e2e/customer-advances-ui-screens.spec.ts` (6 tests).

## Known, not changed here
* The statement ledger lists receipts of every status as payments (pre-existing). A receipt voided later still counts as paid in the ledger rows and totals, while the position cards (as-of functions) stop counting it from its reversal date. Not touched in this task; flagged for a decision.
* `tests/e2e/portal-statement.spec.ts` (pre-existing) logs in with a password form the portal no longer has (it is passwordless now); it fails on the login step at the login step, before reaching the statement page I changed, so it neither confirms nor refutes this work and was not run against a clean checkout.
