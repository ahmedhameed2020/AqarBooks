"""Final review bundle for the local closure of the customer-advances work (and the uncommitted Phase 1-3 tree it sits on).
Local only. Reads git status; copies in-scope files; scans for secrets; writes MANIFEST.md, SHA256SUMS.txt and README.txt."""
import hashlib, os, re, subprocess, sys, zipfile, datetime

ROOT = r"D:\Web\AqarBooks"
os.chdir(ROOT)
OUT = "docs/audits/customer-advances-final-review-bundle.zip"

INCLUDE = ("app/", "components/", "lib/", "tests/", "scripts/demo-local/", "supabase/migrations/", "docs/audits/", "docs/runbooks/",
           "docs/superpowers/", "package.json", "playwright.config.ts", "vitest.config.ts")
EXCLUDE_PREFIX = ("lib/payments/", "tests/payments/", "docs/audits/_parts/")  # the user's separate Fawry / payment-provider work
EXCLUDE_EXACT = {"lib/actions/online-payment-checkout.ts"}
NEVER = [re.compile(p, re.I) for p in (r"(^|/)\.env", r"\.dev\.vars$", r"\.pem$", r"\.key$", r"\.p12$", r"id_rsa", r"(^|/)\.mcp\.json$",
                                       r"secrets?\.", r"service[-_]?account", r"node_modules/", r"(^|/)\.next/", r"(^|/)\.open-next/",
                                       r"test-results/", r"\.zip$", r"__pycache__", r"\.pyc$")]
MIGRATION_FROM = "20261009"

porcelain = subprocess.run(["git", "status", "--porcelain=v1", "-z", "--untracked-files=all"], capture_output=True, text=True, encoding="utf-8").stdout.split("\0")
changed = {}
for entry in porcelain:
    if not entry: continue
    status, path = entry[:2], entry[3:]
    if "D" in status: continue
    changed[path] = "new (untracked)" if status.startswith("??") else "modified (tracked)"

def walk(d):
    out = []
    for r, _, fs in os.walk(d):
        for f in fs: out.append(os.path.join(r, f).replace("\\", "/"))
    return out

wanted = {}
for p, kind in sorted(changed.items()):
    if not p.startswith(INCLUDE) and p not in INCLUDE: continue
    if p in EXCLUDE_EXACT or p.startswith(EXCLUDE_PREFIX): continue
    if p.startswith("supabase/migrations/") and not (os.path.basename(p) >= MIGRATION_FROM and p.endswith(".sql")): continue
    if any(n.search(p) for n in NEVER): continue
    wanted[p] = kind
# documents and evidence that live in untracked folders as a whole
for d, exts, kind in (("docs/audits", (".md",), "report"), ("docs/runbooks", (".md",), "runbook"), ("docs/superpowers", (".md",), "spec/plan"),
                      ("docs/audits/phase3-evidence", (".md", ".log", ".json", ".txt", ".png", ".py", ".sql"), "evidence"),
                      ("docs/audits/phase2-evidence", (".log",), "evidence (earlier phase)"),
                      ("docs/audits/portal-review-evidence", (".log", ".json", ".txt"), "evidence (earlier phase)")):
    for p in walk(d):
        if not p.endswith(exts): continue
        if p.startswith(EXCLUDE_PREFIX) or any(n.search(p) for n in NEVER): continue
        wanted.setdefault(p, kind)

secret = re.compile(r"(eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}|sb_secret_|sk_live_|-----BEGIN [A-Z ]*PRIVATE KEY)")
env_vals = set()
for f in (".env.local", ".env", ".env.production"):
    if os.path.exists(f):
        for line in open(f, encoding="utf-8", errors="ignore"):
            m = re.match(r"\s*(?:export\s+)?(\w+)\s*=\s*(.*)\s*$", line)
            if m:
                v = m.group(2).strip("'\"")
                # NEXT_PUBLIC_* URLs are public by definition (they ship in the browser bundle); everything else >= 8 chars is treated as secret
                if len(v) >= 8 and not (m.group(1).startswith("NEXT_PUBLIC_") and v.startswith("http")): env_vals.add(v)

rows = []
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for p, kind in sorted(wanted.items()):
        data = open(p, "rb").read()
        if not p.endswith(".png"):
            t = data.decode("utf-8", "ignore")
            if secret.search(t) or any(v in t for v in env_vals):
                sys.exit(f"ABORT: secret-like content in {p}")
        z.writestr("files/" + p, data)
        rows.append((p, len(data), hashlib.sha256(data).hexdigest(), kind))
    manifest = ["# Manifest — customer advances, final local review bundle", "",
                f"Built {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')} from the working tree of branch `fix/phase1-financial-report-authz`. **Local only: nothing committed, pushed or deployed.**",
                "Every file below is also listed with its SHA-256 in `SHA256SUMS.txt`; `node scripts/demo-local/verify-review-bundle.mjs <zip>` recomputes them.", "",
                "## Scope and exclusions",
                "* In: modified and new files under app/, components/, lib/, tests/, scripts/demo-local/, supabase/migrations/ (from 20261009), docs/audits, docs/runbooks, docs/superpowers, config; and all evidence under docs/audits/phase3-evidence (plus the earlier phases' logs).",
                "* Out: `lib/payments/`, `tests/payments/` and `lib/actions/online-payment-checkout.ts` (separate Fawry work), tooling and agent files, mobile app, anything env/key/credential-shaped (scanned: file contents against the values of every `.env*` variable and generic secret patterns; a hit aborts the build; public `NEXT_PUBLIC_*` URLs are not treated as secrets), zips, build output.", "",
                "## What the evidence covers and what it does not (verification limits)",
                "* Evidence: isolated stack `aqarbooks_clean` + production build; development database untouched.",
                "* The browser regression is a set of passes over several runs with declared flakes (`accounting-duplicates` D1 -- 12 failures in 38 runs --, `portal-journey` J2/J4); it is **not** one complete green run. Per-run table: `docs/audits/Phase3-Customer-Advances-Closure-Report-2026-10-12.md` §3 and `docs/audits/phase3-evidence/task6-run-record.md`.",
                "* `stack verify`: ledger vs files 81/81 matched -- this proves the migration registry equals the files, **not** that the schema is sound. The first `supabase db diff` failure came from an incomplete stack project folder (21 of 81 migrations; fixed: `verify` re-syncs and checks the count). After that, 11 diff runs gave 9 clean and 2 DRIFT reports with an incomplete-shadow signature, cause unknown; `verify` now diffs twice and prints UNSTABLE (exit 2) on disagreement (that detector has not met a real unstable case). See `docs/audits/phase3-evidence/task7-stack-verify-runs.md`.",
                "* Stranded credit (G-ADV-1) can be cleared in the books only by voiding the receipt -- after any applications in force are reversed, with `finance.payments.void`, in an open fiscal period; the void does not prove the cash was returned to the customer.",
                "* **Open before any deployment approval:** (1) schema-drift check: OPEN. Investigated in `docs/audits/phase3-evidence/task9-drift/result.md`: a DRIFT-like report (same statement counts as the historical one) was reproduced once under CPU load and likely comes from the diff tool, but the independent catalog comparison of that instance was NOT completed and the cause is unknown; on an idle run the catalogs of the live database and of the CLI's shadow were identical (0 of 4,500 facts differ) and the comparison catches a deliberate real difference; `verify` now applies a conservative rule (CLEAN only when the first two observations are clean; any difference or tool error then clean = UNSTABLE; the same difference twice = DRIFT_REPRODUCED; all outputs kept; tests/drift-verdict.test.ts); 82/82 and two clean observations are useful but do not close it, (2) the Playwright flakes: located in statement timeouts (8 s) on units/members_with_financials that the pages show as empty data (7 of 8 failing D1 runs contained a timeout, 0 of 6 passing ones); WHY the queries sometimes exceed 8 s is not established, the page error states were then implemented (error view with Retry; red/green proof in `task7-error-states.md`) which now makes the timeouts visible (39 real ones in one regression session, 32 on the portal home) -- the views were then rewritten by migration 20261017100800 (single lookups 2-3.5 s -> ~30 ms on the 839-org stack; list and organization-wide queries NOT improved; equivalence proven against the old definitions; base-table RLS cost on dues/payments/chart_of_accounts is untouched and still reaches 5-7 s here) -- see `docs/audits/phase3-evidence/task8-views/result.md` and `task7-flake-analysis.md`. Also: the payments dialog's default deposit account now has an explicit order (ascending code; `lib/finance/deposit-accounts.ts`, test included) and `owner-portal-isolation` was repaired (active membership + passwordless login helper); PERFORMANCE AND PERMISSIONS BATCH CLOSED for its scope (docs/audits/phase3-evidence/task10-rls/CLOSURE-performance-and-permissions.md): five forward migrations (the two views; chart_of_accounts / fiscal_periods / dues_select_permission; the platform-admin check as an InitPlan; journal_entries + journal_entry_lines; fiscal_years), each with an equivalence test run red before / green after, a negative control that fails as required and a catalog diff showing only the intended policies; no grant, write policy or timeout touched. FINAL RUN after the last change: Vitest file by file 26/26 (membership-status-access 17/17, the 40 local-sql tests, owner-statement-settlement 8/8), Playwright 9/9 first run, schema verify CLEAN (ledger 86/86, catalogs identical). owner-statement-settlement passes now; the cause of its earlier failure is NOT resolved. NOT covered: the ~80 other tables with per-row permission helpers, the owner-route policies of dues; the schema-drift item stays open (the tool was unstable, its intermittent reports never explained). Full sequential runs: `docs/audits/phase3-evidence/task10-rls/final-run/RESULT.md` (before the RLS migration) and `final-run-after-rls/RESULT.md` (after), (3) G-ADV-1 and the cash refund / credit transfer outside V1. **Conditional, not a general blocker:** linking imported Accsys receipts to their journal entries applies only if Bagoush village (whose Access file Accsys imports) decides to migrate; the legacy-receipt test does not mean their data migration was done.",
                "* The 557-test suite was not repeated for the closure; only the affected files were rerun (see report §3.3).",
                "* Open by design: G-ADV-1 (stranded credit after an ownership transfer: no transfer/refund tool), cash refund, credit transfer between members; not field-verified; not production.", "",
                "## Files", "", "| path | bytes | sha256 | kind |", "|---|---:|---|---|"]
    manifest += [f"| `{p}` | {n} | `{h}` | {k} |" for p, n, h, k in rows]
    mtxt = "\n".join(manifest) + "\n"
    z.writestr("MANIFEST.md", mtxt)
    z.writestr("SHA256SUMS.txt", "\n".join(f"{h}  files/{p}" for p, n, h, k in rows) + "\n")
    z.writestr("README.txt", "Customer advances — final local review bundle. Read MANIFEST.md first (scope, exclusions, verification limits).\nNot an approval for deployment.\n")
    z.writestr("BUILD.py", open(__file__, encoding="utf-8").read())
digest = hashlib.sha256(open(OUT, "rb").read()).hexdigest()
print(len(rows), "files", os.path.getsize(OUT), "bytes", digest)
