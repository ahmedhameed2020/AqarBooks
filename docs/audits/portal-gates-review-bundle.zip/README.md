# Phase 2 → 2c review bundle (secret-free)

Produced locally; nothing committed, pushed, deployed or uploaded. Start with `files/docs/audits/Phase2-Accounting-Journey-Acceptance-Report-2026-10-10.md`
and `files/docs/runbooks/accounting-demo-local.md`.

## What is inside
* **Reports and runbooks:** `files/docs/audits/*.md` (Phase 1, 1.1, 1.2, 2 + the audit), `files/docs/runbooks/*.md`.
* **Migrations (7, complete):** `files/supabase/migrations/20261009120000…`, `…130000…`, `…140000…`, `20261010120000…`, `20261011100000…`, `20261011100100…`, `20261012100000…`.
* **Code and tests:** every file git reports as modified **or untracked** under `app/ components/ lib/ tests/ scripts/demo-local/` plus `package.json`, `playwright.config.ts`, `vitest.config.ts` — including the new files a `git diff` patch would miss. The kind (new / modified) is in MANIFEST.md.
* **Results:** `files/docs/audits/phase2-evidence/*.log.txt` (run logs; `.txt` so they are never mistaken for configuration) and the main screenshots under `files/docs/audits/phase2-evidence/screens/`.

## What is deliberately NOT inside
* Any `.env*`, `.dev.vars`, key, certificate or MCP configuration; `node_modules`, `.next`, `.open-next`, test traces.
* Unrelated work already present in the working tree (the Fawry / payment-provider and mobile changes) — 150 changed paths are outside this review; they are listed in `NOT-INCLUDED.txt` by path only.

## Secret scan (run before anything was written)
Every included text file was checked for: the value of every variable in `.env.local`, `.env.production`, `.env`, `.dev.vars`; the local clean stack's anon / service-role / JWT keys; JWT-shaped tokens, Supabase `sb_*` keys, private-key blocks, AWS key ids, payment-provider secret keys, key/secret/token literals, and connection strings with passwords. **Result: no hit.**
Known, disclosed constants (not secrets): 11 test file(s) contain the fixed password of **disposable local test users** (`scripts/demo-local/make-review-bundle.mjs`, `tests/dunning.integration.test.ts`, `tests/e2e/helpers/accounting-fixture.ts`, `tests/exchange-rates.integration.test.ts`, `tests/fx-difference.integration.test.ts`, `tests/member-opening-balance.integration.test.ts`, `tests/payments/payment-provider-settings-reverify.test.ts`, `tests/payments/payment-provider-verification-race.test.ts`, `tests/payments/resolve-credentials.test.ts`, `tests/project-wip.integration.test.ts`, `tests/purchasing-invoice-vat-wht.integration.test.ts`). They only work on a local throw-away Supabase stack. Rotate nothing; do not reuse them elsewhere.

## Reproduce
`npm run demo:stack-up` → `node scripts/demo-local/build.mjs --next-only` → `node scripts/demo-local/start-prod.mjs` → `npm run demo:e2e -- <specs>` (see the runbook).
